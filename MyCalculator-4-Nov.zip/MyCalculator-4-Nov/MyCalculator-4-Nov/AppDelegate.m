//
//  AppDelegate.m
//  MyCalculator-4-Nov
//
//  Created by Kumar on 04/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    return YES;
    
    
    //Post login method
    
    /*
     NSString *queryString=[NSString stringWithFormat:@"http://ec2-52-71-244-12.compute-1.amazonaws.com:8080/api/v1/user/login"];
     
     
     NSMutableURLRequest *theRequest=[NSMutableURLRequest
     requestWithURL:[NSURL URLWithString:
     queryString]
     cachePolicy:NSURLRequestUseProtocolCachePolicy
     timeoutInterval:60.0];
     NSDictionary *jsonDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
     @"john@doe.com", @"userName",
     @"password2", @"password",
     nil];
     
     
     NSError *error;
     NSData* jsonData = [NSJSONSerialization dataWithJSONObject:jsonDictionary
     options:NSJSONWritingPrettyPrinted error:&error];
     [theRequest setHTTPMethod:@"POST"];
     [theRequest addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
     [theRequest addValue:@"application/json" forHTTPHeaderField:@"Accept"];
     [theRequest setHTTPBody:jsonData];
     NSData* responseData = nil;
     NSURLResponse* response;
     
     responseData=[NSURLConnection sendSynchronousRequest:theRequest returningResponse:&response error:&error];
     NSLog(@"%@",responseData);
     
     
     
     NSString *responseString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
     NSDictionary* json = [NSJSONSerialization JSONObjectWithData:responseData
     options:kNilOptions
     error:&error];
     
     NSLog(@"%@",[json valueForKey:@"status"]);
     
     NSString *statusCode=[NSString stringWithFormat:@"%@",[json valueForKey:@"status"]];
     if([statusCode isEqualToString:@"200"])
     {
     NSLog(@"Say hello");
     [[NSUserDefaults standardUserDefaults]setObject:@"YES" forKey:@"token"];
     
     }
     
     NSLog(@"the final output is:%@",responseString);
     */
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
