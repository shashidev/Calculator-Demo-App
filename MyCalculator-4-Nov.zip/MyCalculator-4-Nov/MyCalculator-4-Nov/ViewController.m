//
//  ViewController.m
//  MyCalculator-4-Nov
//
//  Created by Kumar on 04/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)Add:(id)sender {
    
    if (RunningTotal==0) {
        RunningTotal=SelectNumber;
    }
    else
    {
        switch (Method) {
            case 1:
                RunningTotal=RunningTotal*SelectNumber;
                break;
            case 2:
                RunningTotal=RunningTotal-SelectNumber;
                break;
            case 3:
                RunningTotal=RunningTotal/SelectNumber;
                break;
            case 4:
                RunningTotal=RunningTotal+SelectNumber;
                break;
                
            default:
                break;
        }
    }
    
    Method=4;
    SelectNumber=0;
    

}

- (IBAction)Number1:(id)sender {
    
    
    SelectNumber=SelectNumber*10;
    SelectNumber=SelectNumber+1;
    _Screen.text=[NSString stringWithFormat:@"%i",SelectNumber];
    
}

- (IBAction)Number2:(id)sender {
    
    SelectNumber=SelectNumber*10;
    SelectNumber=SelectNumber+2;
    _Screen.text=[NSString stringWithFormat:@"%i",SelectNumber];
}

- (IBAction)Number3:(id)sender {
    
    SelectNumber=SelectNumber*10;
    SelectNumber=SelectNumber+3;
    _Screen.text=[NSString stringWithFormat:@"%i",SelectNumber];
    
    
}

- (IBAction)Number4:(id)sender {
    
    SelectNumber=SelectNumber*10;
    SelectNumber=SelectNumber+4;
    _Screen.text=[NSString stringWithFormat:@"%i",SelectNumber];
    
}

- (IBAction)Number5:(id)sender {
    
    SelectNumber=SelectNumber*10;
    SelectNumber=SelectNumber+5;
    _Screen.text=[NSString stringWithFormat:@"%i",SelectNumber];
    
}

- (IBAction)Number6:(id)sender {
    
    SelectNumber=SelectNumber*10;
    SelectNumber=SelectNumber+6;
    _Screen.text=[NSString stringWithFormat:@"%i",SelectNumber];
    
}

- (IBAction)Number7:(id)sender {
    
    SelectNumber=SelectNumber*10;
    SelectNumber=SelectNumber+7;
    _Screen.text=[NSString stringWithFormat:@"%i",SelectNumber];
    
}

- (IBAction)Number8:(id)sender {
    
    SelectNumber=SelectNumber*10;
    SelectNumber=SelectNumber+8;
    _Screen.text=[NSString stringWithFormat:@"%i",SelectNumber];
    
}

- (IBAction)Number9:(id)sender {
    
    SelectNumber=SelectNumber*10;
    SelectNumber=SelectNumber+9;
    _Screen.text=[NSString stringWithFormat:@"%i",SelectNumber];
    
}

- (IBAction)Number0:(id)sender {
    
    SelectNumber=SelectNumber*10;
    SelectNumber=SelectNumber+0;
    _Screen.text=[NSString stringWithFormat:@"%i",SelectNumber];
    
}

- (IBAction)Times:(id)sender {
    
    if (RunningTotal==0) {
        RunningTotal=SelectNumber;
    }
    else
    {
        switch (Method) {
            case 1:
                RunningTotal=RunningTotal*SelectNumber;
                break;
            case 2:
                RunningTotal=RunningTotal-SelectNumber;
                break;
            case 3:
                RunningTotal=RunningTotal/SelectNumber;
                break;
            case 4:
                RunningTotal=RunningTotal+SelectNumber;
                break;
                
            default:
                break;
        }
    }
    
    Method=1;
    SelectNumber=0;
}
- (IBAction)Subtract:(id)sender {
    
    if (RunningTotal==0) {
        RunningTotal=SelectNumber;
    }
    else
    {
        switch (Method) {
            case 1:
                RunningTotal=RunningTotal*SelectNumber;
                break;
            case 2:
                RunningTotal=RunningTotal-SelectNumber;
                break;
            case 3:
                RunningTotal=RunningTotal/SelectNumber;
                break;
            case 4:
                RunningTotal=RunningTotal+SelectNumber;
                break;
                
            default:
                break;
        }
    }

    Method=2;
    SelectNumber=0;
}

- (IBAction)Divide:(id)sender {
    
    
    if (RunningTotal==0) {
        RunningTotal=SelectNumber;
    }
    else
    {
        switch (Method) {
            case 1:
                RunningTotal=RunningTotal*SelectNumber;
                break;
            case 2:
                RunningTotal=RunningTotal-SelectNumber;
                break;
            case 3:
                RunningTotal=RunningTotal/SelectNumber;
                break;
            case 4:
                RunningTotal=RunningTotal+SelectNumber;
                break;
                
            default:
                break;
        }
    }

    Method=3;
    SelectNumber=0;
    
}

- (IBAction)Equals:(id)sender {
    
    if (RunningTotal==0) {
        RunningTotal=SelectNumber;
    }
    else
    {
        switch (Method) {
            case 1:
                RunningTotal=RunningTotal*SelectNumber;
                break;
            case 2:
                RunningTotal=RunningTotal-SelectNumber;
                break;
            case 3:
                RunningTotal=RunningTotal/SelectNumber;
                break;
            case 4:
                RunningTotal=RunningTotal+SelectNumber;
                break;
                
            default:
                break;
        }
    }

    
    Method=0;
    SelectNumber=0;
    
    _Screen.text=[NSString stringWithFormat:@"%.2f",RunningTotal];
    
}

- (IBAction)CLR:(id)sender {
    
    Method=0;
    SelectNumber=0;
    RunningTotal=0;
    _Screen.text=[NSString stringWithFormat:@"0"];
    
}
@end
