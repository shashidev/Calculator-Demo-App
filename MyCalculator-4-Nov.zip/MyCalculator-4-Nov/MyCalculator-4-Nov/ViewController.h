//
//  ViewController.h
//  MyCalculator-4-Nov
//
//  Created by Kumar on 04/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

int Method;
int SelectNumber;
float RunningTotal;

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *Screen;
- (IBAction)Add:(id)sender;

- (IBAction)Number1:(id)sender;
- (IBAction)Number2:(id)sender;
- (IBAction)Number3:(id)sender;
- (IBAction)Number4:(id)sender;
- (IBAction)Number5:(id)sender;
- (IBAction)Number6:(id)sender;
- (IBAction)Number7:(id)sender;
- (IBAction)Number8:(id)sender;
- (IBAction)Number9:(id)sender;
- (IBAction)Number0:(id)sender;


- (IBAction)Times:(id)sender;

- (IBAction)Subtract:(id)sender;

- (IBAction)Divide:(id)sender;
- (IBAction)Equals:(id)sender;
- (IBAction)CLR:(id)sender;

@end

